package model;

public interface Asteroid {

	public void shatter();

}
