package observer;

public interface Observer {

	public void updateObserver();

}
