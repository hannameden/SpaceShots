module SpaceShots {
	requires java.desktop;
}